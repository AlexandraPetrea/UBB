#pragma once
#include "Film.h"
#include <iostream>

using namespace std;

class Test {
public:
	void test_film();
	//test the film 
	void test_repository();
	//test the repository
	void test_controller();
	//test the controller
	void test_everything();
	//test all the project

};

